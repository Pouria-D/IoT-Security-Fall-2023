#!/bin/sh
ln -s ../shared extension/shared
ln -s ../shared app/shared
